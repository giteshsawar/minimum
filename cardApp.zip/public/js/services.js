(function() {
    
    var app = angular.module("cardApp");
    
        app.factory('socket', function ($rootScope) {
          var socket = io.connect();
            return {
                on: function (eventName, callback) {
                    socket.on(eventName, function () {
                        var args = arguments;
                        $rootScope.$apply(function () {
                            callback.apply(socket, args);
                        });
                    });
                },
                emit: function (eventName, data, callback) {
                    socket.emit(eventName, data, function () {
                        var args = arguments;
                        $rootScope.$apply(function () {
                            if (callback) {
                                callback.apply(socket, args);
                            }
                        });
                    })
                },
              removeAllListeners: function (eventName, callback) {
                  socket.removeAllListeners(eventName, function() {
                      var args = arguments;
                      $rootScope.$apply(function () {
                        callback.apply(socket, args);
                      });
                  }); 
              }
            };
        });
    
    app.factory('deal', function() {
       
        
        var cardType = ["Hearts", "Spades", "Diamonds", "Clubs"];
        var cardNum = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
        
        var dataObj = {
            deck: [],
            cardCollect: cardCollect,
            shuffleDeck: shuffleDeck
            
        }
        return dataObj;
        
        function cardCollect() {
            
            for(i=0; i<4; i++) {
                
                for(j=0; j<13; j++) {
                    
                    var type = cardType[i];
                    var value = cardNum[j];
                    
                    fillDeck(value, type);
                }
            }
            shuffleDeck();
        }
        
        function fillDeck(value, type) {
            
            switch(type) {
                case "Hearts":
                        img = "img/heart.png"
                    break;
                    case "Spades":
                        img = "img/spade.jpg"
                    break;
                    case "Diamonds":
                        img = "img/diamond.png"
                    break;
                    case "Clubs":
                        img = "img/club.jpg"
                    break;
                       }
            
            var card = {
                value: value,
                type: type,
                img: img
            }
            
            dataObj.deck.push(card);
            
        };
        
        function shuffleDeck() {
        
            var i = dataObj.deck.length, j, temp;
            while(--i > 0) {
                
                j = Math.floor(Math.random() * (i+1));
                temp = dataObj.deck[j];
                dataObj.deck[j] = dataObj.deck[i];
                dataObj.deck[i] = temp;
            }
            
        };
        
        
    });
    
})();