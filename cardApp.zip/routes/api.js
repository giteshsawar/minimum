var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);

module.exports = function() {

var socket_list = {};
var player_list = [];

var Player = function(id) {
    
    var self = {
        id: id,
        cards: []
    }
    return self;
}
   
   

}