(function() {
    
    var app = angular.module("cardApp");
    
    app.controller("indexController", ["$scope", "socket", function($scope, socket) {
        
        $scope.state = '';
        socket.on('state', function(data) {
            
            $scope.state = data;
        });
        
        $scope.enter = function() {
            
            socket.emit('redirect', 'main');
        };
        
        socket.on('redirect', function(data) {
            $scope.state = data;
        });
        
    }]);
    
    app.controller("mainController", ["$scope", "socket", "$window", function($scope, socket, $window) {
        
        $scope.emptyArray = function() {
            
            socket.emit('emptyarray');
        };
        
        $scope.createGroup = function() {
            
            $scope.message = "";
            socket.emit('redirect', 'group');
            socket.emit('createGroup');
        };
        
        $scope.joinGroup = function() {
            
            $scope.message = "";
            socket.emit('redirect', 'group');
            socket.emit('joinGroup');
        };
        
        $scope.showGroup = function() {
            
            socket.emit('showGroup');
        };
        
        
        
    }]);
    
})();