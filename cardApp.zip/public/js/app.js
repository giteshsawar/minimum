'use strict';
    
    var app = angular.module("cardApp", ["ngRoute"]);
        app.config(function($routeProvider) {
        
        $routeProvider
            .when('/', {
                    templateUrl: 'main.html',
                    controller: 'mainController'
            })
            .when('/table', {
                    templateUrl: 'table.html',
                    controller: 'groupController'
            });
    });