var express = require('express');
var app = express();
var path = require('path');
var http = require('http').Server(app);
var io = require('socket.io')(http);
var port = process.env.PORT || 3000;
var api = require('./routes/api');

app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', api);

var socket_list = {};
var players_list = [];

var Player = function(id) {
    
var self = {
        id: id,
        points: 0,
        group: String,
        turn: false,
        cards: []
    };
    return self;
}
var Group = function(name) {
    
    var self = {
        name: name,
        deck: [],
        players: []
    }
    return self;
}
var Players_info = function(id, cards) {
     var self = {
         id: id,
         cards: cards,
         points: 0
     }
     return self;
 }

var groups = [];
var groupsPlaying = [];

 io.on("connection", function(socket) {
    
     var deck = [];
     
     var id = Math.floor(Math.random()*99999);
     var player = new Player(id);
     players_list.push(player);
     
      socket_list[player.id] = socket;
     console.log(players_list.length + "socket connected");
     
     socket.on('redirect', function(data) {
         socket.emit('state', data);
     });
     
     socket.on("createGroup", function() {
         
         var groupname = "group"+player.id;
         var group = new Group(groupname);
         group.players.push(player);
         groups.push(group);
         
         socket.userid = player.id;
         socket.group = groupname;
         socket.join(groupname);
         socket.emit('create', player);
         return;
     });
     
     socket.on("joinGroup", function() {
        
         if(groups.length === 0) {
             socket.emit("Nogroup", "No groups exist");
         }
         else {
             for(var i=0;i< groups.length;i++) {
                 if(groups[i].players.length < 4) {
                     
                     socket.userid = player.id;
                     socket.group = groups[i].name;
                     groups[i].players.push(player);
                     socket.join(socket.group);
                     socket.emit('updategroup', groups[i].players);
                     socket.broadcast.to(socket.group).emit('join', {id: socket.userid, players: groups[i].players});
                     return;
                 }
             }
             socket.emit("Nogroup", "No group is empty");
         }
     });
     
     socket.on("emptyarray", function() {
         groups = [];
         console.log(groups);
     });
     
     socket.on("showGroup", function() {
         console.log(groupsPlaying);
     });
     
     socket.on("startPlay", function() {
         
         for(var i in groups) {
             if(groups[i].name === socket.group) {
                 
                 groupsPlaying.push(groups[i]);
                 groups.splice(i, 1);
             }
         }
         socket.emit("deal");
     });
     
     socket.on("dealCards", function(data) {
         
         for(var i in groupsPlaying) {
             
             if(groupsPlaying[i].name === socket.group) {
                 
                 groupsPlaying[i].deck = [];
                 for(var j in data.deck) {
                    groupsPlaying[i].deck.push(data.deck[j]);
                 }
                 
                 for(var j in groupsPlaying[i].players) {
                     
                     groupsPlaying[i].players[j].cards = [];
                 }
                 
                 var plylgth = groupsPlaying[i].players.length, j = 0, tot_players = [];
                 while(j<7) {
                     for(var k=0; k<plylgth; k++) {
                         groupsPlaying[i].players[k].cards.push(groupsPlaying[i].deck[0]);
                         groupsPlaying[i].deck.splice(0, 1);
                     }
                     j++
                 }
                 
                 tot_players = [];
                 for(var j in groupsPlaying[i].players) {
                     
                     var players = new Players_info(groupsPlaying[i].players[j].id, groupsPlaying[i].players[j].cards.length);
                     players.points = groupsPlaying[i].players[j].points;
                     tot_players.push(players);
                 }
                 
                 for(var j in groupsPlaying[i].players) {
                      
                    socket_list[groupsPlaying[i].players[j].id].emit("startGame", {deck: groupsPlaying[i].deck, player: groupsPlaying[i].players[j], tot_players: tot_players});
                     
                     if(groupsPlaying[i].players[j].id === data.winner) {
                         
                         groupsPlaying[i].players[j].turn = true;
                         socket_list[groupsPlaying[i].players[j].id].emit("playTurn", "Your Turn");
                     }
                    
                 }
                     if(data.winner === "") {
                         
                         groupsPlaying[i].players[0].turn = true;
                         socket.emit('redirect', 'table');
                         socket.broadcast.to(socket.group).emit('redirect', 'table');
                         socket_list[groupsPlaying[i].players[0].id].emit("playTurn", "Your Turn");
                     }
             }
         }
     });
     
     socket.on("nextTurn", function(data) {
        
         for(var i in groupsPlaying) {
             
             if(groupsPlaying[i].name === socket.group) {
                 
                 groupsPlaying[i].deck = [];
                 for(var j in data.deck) {
                     groupsPlaying[i].deck.push(data.deck[j]);
                 }
                 
                 for(var j in groupsPlaying[i].players) {
                     
                     if(groupsPlaying[i].players[j].id === socket.userid) {
                         
                         groupsPlaying[i].players[j].cards = [];
                         
                         for(var k in data.cards) {
                             groupsPlaying[i].players[j].cards.push(data.cards[k]);
                         }
                         socket_list[socket.userid].emit("updatePlayer", {deck: groupsPlaying[i].deck, player: groupsPlaying[i].players[j]});
                         socket.broadcast.to(socket.group).emit("updateTable", {id: groupsPlaying[i].players[j].id, cards: groupsPlaying[i].players[j].cards.length, deck: groupsPlaying[i].deck});
                         groupsPlaying[i].players[j].turn = false;
                         
                         if(parseInt(j) === (groupsPlaying[i].players.length-1)) {
                             groupsPlaying[i].players[0].turn = true;
                             socket_list[groupsPlaying[i].players[0].id].emit("playTurn", "Your Turn");
                         }
                         else {
                             var turn = (parseInt(j)+1);
                             groupsPlaying[i].players[turn].turn = true;
                             socket_list[groupsPlaying[i].players[turn].id].emit("playTurn", "Your Turn");
                         }
                     }
                 }
             }
         }
        
     });
     
     socket.on("showCalled", function() {
         
         var tablePoints = [], winner, winner_id = [], caller, final_winner = [];
        
         for(var i in groupsPlaying) {
             
             if(groupsPlaying[i].name === socket.group) {
                 
                 for(var j in groupsPlaying[i].players) {
                     
                     var points = 0;
                     groupsPlaying[i].players[j].turn = false;
                     
                     for(var k in groupsPlaying[i].players[j].cards) {

                         points += groupsPlaying[i].players[j].cards[k]['value'];
                     }

                     tablePoints.push(points);

                     if(groupsPlaying[i].players[j].id === socket.userid) {

                            caller = j;
                     }
                 }
                 
                 for(var j in tablePoints) {
             
                    if(tablePoints[j] === tablePoints[caller] || tablePoints[j] < tablePoints[caller]) {

                            if(j != caller) {
                                winner_id.push(groupsPlaying[i].players[j].id);
                                groupsPlaying[i].players[j].points += tablePoints[caller];
                            }
                     }
                 }
                 
                 for(var j in groupsPlaying[i].players) {
                     
                     if(groupsPlaying[i].players[j].points >= 100) {
                         console.log("geme end");
                         final_winner.push(groupsPlaying[i].players[j].id);
                         console.log(final_winner);
                         socket.broadcast.to(socket.group).emit("gameEnd", {id: final_winner, players: groupsPlaying[i].players});
                         socket.emit("gameEnd", {id: final_winner, players: groupsPlaying[i].players});
                     }
                 }
                 
                 if(final_winner.length === 0) {
                     
                     if(winner_id.length !== 0) {

                         socket.broadcast.to(socket.group).emit("gameLost", {id: winner_id, players: groupsPlaying[i].players});
                         socket.emit("gameLost", {id: winner_id, players: groupsPlaying[i].players});
                     }
                     else {
                         groupsPlaying[i].players[caller].points += tablePoints[caller];
                         socket.emit("gameWon", {id: socket.userid, player: groupsPlaying[i].players[caller]});
                         socket.broadcast.to(socket.group).emit("gameWon", {id: socket.userid, player: groupsPlaying[i].players[caller]});
                     }
                 }
             }
         }
         
     });
     
     socket.on('lastPlayer', function(data) {
       
         for(var i in groupsPlaying) {
             
             if(groupsPlaying[i].name === socket.group) {
                 
                 groupsPlaying[i].players[0].turn = false;
                 groupsPlaying[i].players[0].points = 0;
                 groupsPlaying.splice(i, 1);
                 socket.emit('redirect', '');
             }
         }
         
     });
     
     socket.on("disconnect", function(data) {
         
        players_list.splice(players_list.indexOf(player), 1);
         
        for(var i in groups) {
            if(groups[i].name === socket.group) {
                for(var j in groups[i].players) {
                    
                    if(groups[i].players[j].id === socket.userid) {
                        groups[i].players.splice(j, 1);
                        break;
                    }
                }
                if(groups[i].players.length === 0) {
                    groups.splice(i, 1);
                }
                else {
                    socket.broadcast.to(socket.group).emit("playerLeft", socket.userid);
                     socket.broadcast.to(socket.group).emit('updategroup', groups[i].players);
                }
            }
        } 
         
         for(var i in groupsPlaying) {
             
             if(groupsPlaying[i].name === socket.group) {
                 
                 for(var j in groupsPlaying[i].players) {
                     
                     if(groupsPlaying[i].players[j].id === socket.userid) {
                         
                         var cards = [];
                         for(var k in groupsPlaying[i].players[j].cards) {
                             cards.push(groupsPlaying[i].players[j].cards[k]);
                         }
                         
                         if(groupsPlaying[i].players[j].turn === true) {
                             
                             if(parseInt(j) === (groupsPlaying[i].players.length-1)) {
                                 socket_list[groupsPlaying[i].players[0].id].emit("playTurn", "Your Turn");
                             }
                             else {
                                 var turn = (parseInt(j)+1);
                                 socket_list[groupsPlaying[i].players[turn].id].emit("playTurn", "Your Turn");
                             }
                         }
                         
                         groupsPlaying[i].players.splice(j, 1);
                        
                         socket.broadcast.to(socket.group).emit("playerLeft", {player: socket.userid, cards: cards});
                         return;
                     }
                }
                 
                 if(groupsPlaying[i].players.length < 1) {
                     groupsPlaying.splice(i, 1);
                 }
                 
             }
         }
          
         delete socket_list[player.id];
         
     });
     
     
 });

http.listen(port, function() {
    
    console.log("We are connected");
});