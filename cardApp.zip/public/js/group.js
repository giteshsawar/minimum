(function() {
    
    var app = angular.module("cardApp");
    
    app.controller("groupController", ["$scope", "socket", "deal", function($scope, socket, deal) {
        
        $scope.players = [];
        $scope.deal = deal;
        $scope.nogroup = false;
        
        socket.on('create', function(data) {
           
            $scope.nogroup = false;
            $scope.message = "";
            
            $scope.players = [];
            $scope.players.push(data);
        });
        
        socket.on('join', function(data) {
           
            $scope.message = data.id + " joined the group";
            $scope.players = [];
            
            for(var i=0; i<data.players.length; i++) {
                $scope.players.push(data.players[i]);
            }
        });
        
        socket.on("Nogroup", function(data) {
           
            $scope.nogroup = true;
            $scope.message = data;
        });
        
        socket.on('updategroup', function(data) {
           
            $scope.players = [];
            
            for(var i=0; i<data.length; i++) {
                $scope.players.push(data[i]);
            }
        });
        
        socket.on("playerLeft", function(data) {
           
            $scope.message = data + " left the group";
        });
        
        $scope.startGame = function() {
          
            socket.emit('startPlay');
        };
        
        socket.on('deal', function() {
            
            deal.cardCollect();
            var winner = "";
            
            socket.emit('dealCards', {deck: deal.deck, winner: winner});
        });
        
    }]);
    
})();




